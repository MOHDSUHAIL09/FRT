import React from 'react';
import { Routes, Route } from 'react-router-dom';
import DashboardLayout from '../layouts/DashboardLayout';
import DashboardView from '../pages/Dashboard/DashboardView';
import Refer from '../pages/Dashboard/Refer';
import History from '../pages/Dashboard/History';
import Profile from '../pages/Dashboard/Profile';

const DashboardRoutes = () => {
  return (
    <Routes>
      <Route element={<DashboardLayout />}>
        <Route index element={<DashboardView />} />
        <Route path="refer" element={<Refer />} />
        <Route path="history" element={<History />} />
        <Route path="profile" element={<Profile />} />
      </Route>
    </Routes>
  );
};

export default DashboardRoutes;