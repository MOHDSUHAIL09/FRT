import React, { useState, useEffect, useRef } from 'react';
import { Routes, Route, Navigate, useLocation, useNavigate } from 'react-router-dom';
import { useAccount, useReadContract } from 'wagmi';
import { isAddress } from 'viem';

import Home from './pages/Landing/Home';
import Dashboard from './pages/Dashboard/DashboardView';
import RegistrationModal from './components/RegistrationModal';
import Header from './components/common/Header';
import { REGISTRATION_ABI } from './abi/registrationAbi';

const CONTRACT_ADDRESS = import.meta.env.VITE_CONTRACT_ADDRESS || '0xf8D1615a0Db38BcEf280B5DE5cb5036E2f2aDF11';

console.log(' App - Contract Address:', CONTRACT_ADDRESS);

const App = () => {
  const { isConnected, address } = useAccount();
  const location = useLocation();
  const navigate = useNavigate();
  const [showModal, setShowModal] = useState(false);
  const [isRegistered, setIsRegistered] = useState(false);
  const [isChecking, setIsChecking] = useState(true);
  const modalOpenedRef = useRef(false);

  console.log('🔍 App - Wallet:', address);
  console.log('🔍 App - Is Connected:', isConnected);

  // ✅ Check if user is registered
  const { 
    data: isUserRegistered, 
    isLoading: checkingRegistration, 
    error: regError,
    refetch 
  } = useReadContract({
    address: CONTRACT_ADDRESS,
    abi: REGISTRATION_ABI,
    functionName: 'isRegistered',
    args: [address],
    query: {
      enabled: !!address && address !== '0x' && isAddress(CONTRACT_ADDRESS),
    },
  });

  console.log('📝 App - Is Registered:', isUserRegistered);
  console.log('❌ App - Error:', regError?.message);

  // ✅ Update registration status
  useEffect(() => {
    if (address) {
      setIsChecking(checkingRegistration);
      if (!checkingRegistration) {
        const isReg = isUserRegistered === true;
        setIsRegistered(isReg);
        console.log('📝 App - Registration Status:', isReg ? '✅ Registered' : '❌ Not Registered');
        if (isReg) {
          setShowModal(false);
          modalOpenedRef.current = false;
        }
      }
    } else {
      setIsChecking(false);
      setIsRegistered(false);
    }
  }, [address, isUserRegistered, checkingRegistration]);

  // ✅ Open modal when wallet connects
  useEffect(() => {
    if (isConnected && address && !isChecking && !isRegistered && !modalOpenedRef.current) {
      console.log('✅ Opening registration modal...');
      setShowModal(true);
      modalOpenedRef.current = true;
    }
  }, [isConnected, address, isChecking, isRegistered]);

  // ✅ Handle registration success
  const handleRegistrationSuccess = () => {
    console.log('✅ Registration successful!');
    setIsRegistered(true);
    setShowModal(false);
    modalOpenedRef.current = false;
    setTimeout(() => {
      refetch();
      navigate('/dashboard', { replace: true });
    }, 1000);
  };

  const handleModalClose = () => {
    if (isRegistered) {
      setShowModal(false);
      modalOpenedRef.current = false;
    }
  };

  // ✅ Protected Route
  const ProtectedRoute = ({ children }) => {
    if (showModal) {
      return (
        <div style={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          height: '100vh',
          background: '#0a0e1a',
          color: '#fff'
        }}>
          <div style={{ textAlign: 'center' }}>
            <div className="spinner" style={{
              width: '50px',
              height: '50px',
              border: '3px solid rgba(28,133,234,0.1)',
              borderTop: '3px solid #1c85ea',
              borderRadius: '50%',
              margin: '0 auto 20px'
            }} />
            <p>Please complete registration...</p>
          </div>
        </div>
      );
    }

    if (isChecking) {
      return (
        <div style={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          height: '100vh',
          background: '#0a0e1a',
          color: '#fff'
        }}>
          <div style={{ textAlign: 'center' }}>
            <div className="spinner" style={{
              width: '50px',
              height: '50px',
              border: '3px solid rgba(28,133,234,0.1)',
              borderTop: '3px solid #1c85ea',
              borderRadius: '50%',
              margin: '0 auto 20px'
            }} />
            <p>Checking registration...</p>
          </div>
        </div>
      );
    }

    if (!isConnected || !isRegistered) {
      return <Navigate to="/" replace />;
    }

    return children;
  };

  return (
    <>
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route 
          path="/dashboard" 
          element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          } 
        />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      
      <RegistrationModal 
        isOpen={showModal} 
        onClose={handleModalClose}
        address={address}
        onSuccess={handleRegistrationSuccess}
        contractAddress={CONTRACT_ADDRESS}
        abi={REGISTRATION_ABI}
      />
    </>
  );
};

export default App;